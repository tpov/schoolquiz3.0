package com.tpov.schoolquiz.secure

object secureCode {

    fun getTranslateKey() = "AIzaSyC10iksA0DO5OBc98KY_M1ECeNVHUIU2QQ "
    fun getAdUnitId() = "ca-app-pub-8813769623682903/4422323755"
}